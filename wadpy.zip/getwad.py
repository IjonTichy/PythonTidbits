#!/usr/bin/env python3

import io, os, sys, zipfile
from urllib.request import urlopen
from urllib.error   import HTTPError

BASENAME = os.path.basename(sys.argv[0])
USAGE = "{} <pk3> [dest]".format(BASENAME)

def errorExit(reason):
    print("{}: error: {}".format(BASENAME, reason))
    sys.exit(1)

def usageExit(reason):
    print("{}: error: {}".format(BASENAME, reason))
    print(USAGE)
    sys.exit(128)

if len(sys.argv) < 2:
    usageExit("needs a pk3 name")

FILE = sys.argv[1]
DEST = sys.argv[2:3] or "."

try:
    url = urlopen("http://wadhost.fathax.com/files/{}.zip".format(FILE))
except HTTPError:
    errorExit("\"{}.zip\" could not be retrieved".format(FILE))

urlB = io.BytesIO(url.read())
z    = zipfile.ZipFile(urlB)

z.extractall(DEST)
